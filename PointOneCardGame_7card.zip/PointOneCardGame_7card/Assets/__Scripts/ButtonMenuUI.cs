﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonMenuUI : MonoBehaviour
{
    [Header("Set Dynamically")]
    public Image menuImage;

    public Camera cam;
    public Deck deck;
    //public Card tCard; //targetcard 저장

    void Start()
    {
        menuImage = GetComponent<Image>();
        cam = Camera.main;
        deck = cam.GetComponent<Deck>();
        ShowMenu(false);
    }

    public void ShowMenu(bool show)//메뉴 보이기
    {
        menuImage.gameObject.SetActive(show);
    }

    /*
    public void GetCard(Card card)//targetCard 얻기
    {
        //tCard = new Card();
        tCard = card;
    }
    */

    //card click event
    public void ChangeButtonSpade()
    {
        print("SpadeClick");
        deck.ChangeCard(PointOneCardGame.S.targetCard, "S");
        ShowMenu(false);
    }

    public void ChangeButtonClub()
    {
        print("ClubClick");
        deck.ChangeCard(PointOneCardGame.S.targetCard, "C");
        ShowMenu(false);
    }

    public void ChangeButtonHeart()
    {
        print("HeartClick");
        deck.ChangeCard(PointOneCardGame.S.targetCard, "H");
        ShowMenu(false);
    }

    public void ChangeButtonDiamond()
    {
        print("DiamondClick");
        deck.ChangeCard(PointOneCardGame.S.targetCard, "D");
        ShowMenu(false);
    }
}
